import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Duolingo Clone - Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Xử lý logic đăng nhập
              },
              child: Text('Đăng nhập'),
            ),
            TextButton(
              onPressed: () {
                // Chuyển tới trang đăng ký
              },
              child: Text('Đăng ký tài khoản'),
            ),
          ],
        ),
      ),
    );
  }
}
