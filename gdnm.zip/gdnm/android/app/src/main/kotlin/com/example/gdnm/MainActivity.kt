package com.example.gdnm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
